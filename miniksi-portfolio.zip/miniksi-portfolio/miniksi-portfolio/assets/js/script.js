document.addEventListener("DOMContentLoaded", () => {
  console.log("Miniksi Portfolio Loaded");
});